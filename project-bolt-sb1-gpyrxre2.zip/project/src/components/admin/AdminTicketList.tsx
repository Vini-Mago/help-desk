import { useState, useEffect } from 'react';
import { getTickets, updateTicketStatus, exportTicketsToText, downloadAsTextFile } from '../../utils/fileSystem';
import { Ticket } from '../../utils/types';
import { Clock, CheckCircle2, HelpCircle, Download } from 'lucide-react';

const AdminTicketList = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [message, setMessage] = useState({ text: '', type: '' });
  const [filter, setFilter] = useState<'all' | 'pending' | 'inprogress' | 'resolved'>('all');
  
  useEffect(() => {
    // Load tickets initially
    loadTickets();
  }, []);
  
  const loadTickets = () => {
    const allTickets = getTickets();
    setTickets(allTickets);
  };
  
  const handleStatusChange = (ticketId: string, newStatus: 'pending' | 'inprogress' | 'resolved') => {
    const success = updateTicketStatus(ticketId, newStatus);
    
    if (success) {
      setMessage({ text: 'Status do ticket atualizado com sucesso!', type: 'success' });
      loadTickets(); // Reload tickets after update
    } else {
      setMessage({ text: 'Erro ao atualizar o status do ticket.', type: 'error' });
    }
    
    setTimeout(() => {
      setMessage({ text: '', type: '' });
    }, 3000);
  };
  
  const handleExportTickets = () => {
    const textContent = exportTicketsToText();
    downloadAsTextFile(textContent, 'tickets.txt');
  };
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'technical':
        return <Clock size={18} />;
      case 'financial':
        return <CheckCircle2 size={18} />;
      case 'inquiry':
        return <HelpCircle size={18} />;
      default:
        return null;
    }
  };
  
  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'technical':
        return 'Técnico';
      case 'financial':
        return 'Financeiro';
      case 'inquiry':
        return 'Dúvida';
      default:
        return type;
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR');
  };
  
  // Filter tickets based on status
  const filteredTickets = filter === 'all' 
    ? tickets 
    : tickets.filter(ticket => ticket.status === filter);
  
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ color: '#6a0dad' }}>Gerenciar Tickets</h2>
        
        <button 
          onClick={handleExportTickets}
          style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '6px',
            backgroundColor: '#6a0dad',
            color: 'white',
            border: 'none',
            padding: '8px 16px',
            borderRadius: '8px',
            cursor: 'pointer'
          }}
        >
          <Download size={16} /> Exportar para TXT
        </button>
      </div>
      
      <div style={{ marginBottom: '20px' }}>
        <label style={{ marginRight: '10px', fontWeight: 'bold' }}>Filtrar por status:</label>
        <select 
          value={filter}
          onChange={(e) => setFilter(e.target.value as 'all' | 'pending' | 'inprogress' | 'resolved')}
          style={{ 
            padding: '8px', 
            borderRadius: '4px', 
            border: '1px solid #bfa2db',
            backgroundColor: '#f1e4fc'
          }}
        >
          <option value="all">Todos</option>
          <option value="pending">Pendentes</option>
          <option value="inprogress">Em andamento</option>
          <option value="resolved">Resolvidos</option>
        </select>
      </div>
      
      {message.text && (
        <div className={`message ${message.type}`} style={{ marginBottom: '20px' }}>
          {message.text}
        </div>
      )}
      
      {filteredTickets.length === 0 ? (
        <div style={{ 
          backgroundColor: '#f1e4fc', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'center',
          color: '#6a0dad'
        }}>
          Nenhum ticket encontrado com o filtro atual.
        </div>
      ) : (
        <div>
          {filteredTickets.map((ticket) => (
            <div key={ticket.id} className="ticket">
              <div className="ticket-header">
                <h3 className="ticket-title">{ticket.title}</h3>
                <div>
                  <select 
                    value={ticket.status}
                    onChange={(e) => handleStatusChange(
                      ticket.id, 
                      e.target.value as 'pending' | 'inprogress' | 'resolved'
                    )}
                    style={{ 
                      padding: '6px', 
                      borderRadius: '4px', 
                      border: '1px solid #bfa2db',
                      backgroundColor: '#f1e4fc',
                      marginLeft: '10px'
                    }}
                  >
                    <option value="pending">Pendente</option>
                    <option value="inprogress">Em andamento</option>
                    <option value="resolved">Resolvido</option>
                  </select>
                </div>
              </div>
              
              <div className="ticket-body">
                <p style={{ marginBottom: '10px' }}>{ticket.description}</p>
                <p style={{ color: '#666', fontSize: '0.9rem' }}>
                  <strong>Usuário:</strong> {ticket.username}
                </p>
              </div>
              
              <div className="ticket-footer">
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  {getTypeIcon(ticket.type)}
                  <span>{getTypeLabel(ticket.type)}</span>
                </div>
                <div>
                  Criado em: {formatDate(ticket.createdAt)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminTicketList;