import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

interface AdminLoginFormProps {
  onSwitchToUserLogin: () => void;
}

const AdminLoginForm = ({ onSwitchToUserLogin }: AdminLoginFormProps) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });
  const { adminLogin } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      setMessage({ text: 'Por favor, preencha todos os campos.', type: 'error' });
      return;
    }

    const isLoggedIn = adminLogin(username, password);
    
    if (isLoggedIn) {
      setMessage({ text: 'Login realizado com sucesso!', type: 'success' });
      setTimeout(() => {
        navigate('/admin-dashboard');
      }, 1000);
    } else {
      setMessage({ text: 'Nome de usuário ou senha incorretos.', type: 'error' });
    }
  };

  return (
    <div id="adminLoginForm">
      <h2 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '20px' }}>Login de Administrador</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-control">
          <label htmlFor="adminUsername">NOME DE USUÁRIO:</label>
          <input 
            type="text" 
            id="adminUsername" 
            placeholder="Digite seu nome de usuário"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="form-control">
          <label htmlFor="adminPassword">SENHA:</label>
          <input 
            type="password" 
            id="adminPassword" 
            placeholder="Digite sua senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn">ENTRAR</button>
        
        <div className="switch-button">
          <button type="button" className="btn-link" onClick={onSwitchToUserLogin}>Voltar para login de usuário</button>
        </div>
      </form>

      {message.text && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default AdminLoginForm;