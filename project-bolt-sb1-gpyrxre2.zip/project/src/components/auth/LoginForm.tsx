import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

interface LoginFormProps {
  onSwitchToRegister: () => void;
  onSwitchToAdminLogin: () => void;
}

const LoginForm = ({ onSwitchToRegister, onSwitchToAdminLogin }: LoginFormProps) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setMessage({ text: 'Por favor, preencha todos os campos.', type: 'error' });
      return;
    }

    const isLoggedIn = login(email, password);
    
    if (isLoggedIn) {
      setMessage({ text: 'Login realizado com sucesso!', type: 'success' });
      setTimeout(() => {
        navigate('/user-dashboard');
      }, 1000);
    } else {
      setMessage({ text: 'E-mail ou senha incorretos.', type: 'error' });
    }
  };

  return (
    <div id="loginForm">
      <h2 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '20px' }}>Login</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-control">
          <label htmlFor="loginEmail">E-MAIL:</label>
          <input 
            type="email" 
            id="loginEmail" 
            placeholder="Digite seu e-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-control">
          <label htmlFor="loginPassword">SENHA:</label>
          <input 
            type="password" 
            id="loginPassword" 
            placeholder="Digite sua senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn">ENTRAR</button>
        
        <div className="switch-button">
          <span>Não tem uma conta?</span>
          <button type="button" className="btn-link" onClick={onSwitchToRegister}>Cadastre-se</button>
        </div>
        
        <div className="switch-button" style={{ marginTop: '10px' }}>
          <button type="button" className="btn-link" onClick={onSwitchToAdminLogin}>Entrar como Administrador</button>
        </div>
      </form>

      {message.text && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default LoginForm;