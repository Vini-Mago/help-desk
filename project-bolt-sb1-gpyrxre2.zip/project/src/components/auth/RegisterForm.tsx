import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { User } from '../../utils/types';

interface RegisterFormProps {
  onSwitchToLogin: () => void;
}

const RegisterForm = ({ onSwitchToLogin }: RegisterFormProps) => {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [message, setMessage] = useState({ text: '', type: '' });
  const [currentStep, setCurrentStep] = useState(1);
  
  // Step 1 - Personal Data
  const [name, setName] = useState('');
  const [birthdate, setBirthdate] = useState('');
  const [gender, setGender] = useState('');
  
  // Step 2 - Contact
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  
  // Step 3 - Access
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [preferredContact, setPreferredContact] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  const validateStep1 = () => {
    if (!name) {
      setMessage({ text: 'Por favor, informe seu nome completo.', type: 'error' });
      return false;
    }
    
    if (!birthdate) {
      setMessage({ text: 'Por favor, informe sua data de nascimento.', type: 'error' });
      return false;
    }
    
    if (!validateAge(birthdate)) {
      setMessage({ text: 'Você deve ter pelo menos 18 anos para se cadastrar.', type: 'error' });
      return false;
    }
    
    if (!gender) {
      setMessage({ text: 'Por favor, selecione seu gênero.', type: 'error' });
      return false;
    }
    
    return true;
  };

  const validateStep2 = () => {
    if (!phone || phone.length < 14) {
      setMessage({ text: 'Por favor, informe um telefone válido.', type: 'error' });
      return false;
    }
    
    if (!email) {
      setMessage({ text: 'Por favor, informe seu e-mail.', type: 'error' });
      return false;
    }
    
    if (!validateEmail(email)) {
      setMessage({ text: 'Por favor, informe um e-mail válido.', type: 'error' });
      return false;
    }
    
    if (!city) {
      setMessage({ text: 'Por favor, informe sua cidade.', type: 'error' });
      return false;
    }
    
    if (!state) {
      setMessage({ text: 'Por favor, selecione seu estado.', type: 'error' });
      return false;
    }
    
    if (!zipCode || zipCode.length < 9) {
      setMessage({ text: 'Por favor, informe um CEP válido.', type: 'error' });
      return false;
    }
    
    return true;
  };

  const validateStep3 = () => {
    if (!username) {
      setMessage({ text: 'Por favor, escolha um nome de usuário.', type: 'error' });
      return false;
    }
    
    if (!password) {
      setMessage({ text: 'Por favor, digite uma senha.', type: 'error' });
      return false;
    }
    
    if (password.length < 6) {
      setMessage({ text: 'A senha deve ter no mínimo 6 caracteres.', type: 'error' });
      return false;
    }
    
    if (!/\d/.test(password) || !/[a-zA-Z]/.test(password)) {
      setMessage({ text: 'A senha deve conter letras e números.', type: 'error' });
      return false;
    }
    
    if (password !== confirmPassword) {
      setMessage({ text: 'As senhas não coincidem.', type: 'error' });
      return false;
    }
    
    if (!preferredContact) {
      setMessage({ text: 'Por favor, selecione seu contato preferencial.', type: 'error' });
      return false;
    }
    
    if (!termsAccepted) {
      setMessage({ text: 'Você precisa aceitar os termos de uso e política de privacidade.', type: 'error' });
      return false;
    }
    
    return true;
  };

  const nextStep = () => {
    setMessage({ text: '', type: '' });
    
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2);
    } else if (currentStep === 2 && validateStep2()) {
      setCurrentStep(3);
    }
  };

  const prevStep = () => {
    setMessage({ text: '', type: '' });
    setCurrentStep(currentStep - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStep3()) {
      return;
    }
    
    const userData: User = {
      name,
      birthdate,
      gender,
      email,
      phone,
      city,
      state,
      zipCode,
      username,
      password,
      preferredContact
    };
    
    const isRegistered = register(userData);
    
    if (isRegistered) {
      setMessage({ text: 'Cadastro realizado com sucesso! Agora você pode fazer login.', type: 'success' });
      setTimeout(() => {
        navigate('/login');
      }, 2000);
    } else {
      setMessage({ text: 'Erro ao cadastrar. Este e-mail já está em uso.', type: 'error' });
    }
  };

  const maskPhone = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) {
      value = value.slice(0, 11);
    }
    
    if (value.length > 10) {
      value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    } else if (value.length > 6) {
      value = value.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    } else if (value.length > 2) {
      value = value.replace(/(\d{2})(\d{0,5})/, '($1) $2');
    }
    
    setPhone(value);
  };

  const maskZipCode = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 8) {
      value = value.slice(0, 8);
    }
    
    if (value.length > 5) {
      value = value.replace(/(\d{5})(\d{1,3})/, '$1-$2');
    }
    
    setZipCode(value);
  };

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const validateAge = (birthdate: string) => {
    const today = new Date();
    const birthDate = new Date(birthdate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age >= 18;
  };

  return (
    <div id="registerForm">
      <div className="form-progress">
        <div 
          id="step1Indicator" 
          className={`progress-step ${currentStep === 1 ? 'active' : ''}`}
          onClick={() => setCurrentStep(1)}
        >
          <div className="progress-step-number">1</div>
          <div>Dados Básicos</div>
        </div>
        <div 
          id="step2Indicator" 
          className={`progress-step ${currentStep === 2 ? 'active' : ''}`}
          onClick={() => validateStep1() && setCurrentStep(2)}
        >
          <div className="progress-step-number">2</div>
          <div>Contato</div>
        </div>
        <div 
          id="step3Indicator" 
          className={`progress-step ${currentStep === 3 ? 'active' : ''}`}
          onClick={() => validateStep1() && validateStep2() && setCurrentStep(3)}
        >
          <div className="progress-step-number">3</div>
          <div>Acesso</div>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Step 1 - Personal Data */}
        {currentStep === 1 && (
          <div id="registerStep1">
            <h2 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '20px' }}>Dados Pessoais</h2>
            
            <div className="form-control">
              <label htmlFor="registerName">NOME COMPLETO:</label>
              <input 
                type="text" 
                id="registerName" 
                placeholder="Digite seu nome completo"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div className="form-control">
              <label htmlFor="registerBirthdate">DATA DE NASCIMENTO:</label>
              <input 
                type="date" 
                id="registerBirthdate"
                value={birthdate}
                onChange={(e) => setBirthdate(e.target.value)}
              />
            </div>

            <div className="form-control">
              <label htmlFor="registerGender">GÊNERO:</label>
              <select 
                id="registerGender"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <option value="" disabled>Selecione</option>
                <option value="masculino">Masculino</option>
                <option value="feminino">Feminino</option>
                <option value="outro">Outro</option>
                <option value="nao_informar">Prefiro não informar</option>
              </select>
            </div>

            <button type="button" className="btn" onClick={nextStep}>PRÓXIMO</button>
          </div>
        )}

        {/* Step 2 - Contact */}
        {currentStep === 2 && (
          <div id="registerStep2">
            <h2 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '20px' }}>Informações de Contato</h2>
            
            <div className="form-control">
              <label htmlFor="registerPhone">TELEFONE:</label>
              <input 
                type="text" 
                id="registerPhone" 
                placeholder="(00) 00000-0000" 
                maxLength={15}
                value={phone}
                onChange={maskPhone}
              />
            </div>

            <div className="form-control">
              <label htmlFor="registerEmail">E-MAIL:</label>
              <input 
                type="email" 
                id="registerEmail" 
                placeholder="Digite seu e-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="form-row">
              <div className="form-control">
                <label htmlFor="registerCity">CIDADE:</label>
                <input 
                  type="text" 
                  id="registerCity" 
                  placeholder="Cidade"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
              
              <div className="form-control">
                <label htmlFor="registerState">ESTADO:</label>
                <select 
                  id="registerState"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                >
                  <option value="" disabled>UF</option>
                  <option value="AC">AC</option>
                  <option value="AL">AL</option>
                  <option value="AP">AP</option>
                  <option value="AM">AM</option>
                  <option value="BA">BA</option>
                  <option value="CE">CE</option>
                  <option value="DF">DF</option>
                  <option value="ES">ES</option>
                  <option value="GO">GO</option>
                  <option value="MA">MA</option>
                  <option value="MT">MT</option>
                  <option value="MS">MS</option>
                  <option value="MG">MG</option>
                  <option value="PA">PA</option>
                  <option value="PB">PB</option>
                  <option value="PR">PR</option>
                  <option value="PE">PE</option>
                  <option value="PI">PI</option>
                  <option value="RJ">RJ</option>
                  <option value="RN">RN</option>
                  <option value="RS">RS</option>
                  <option value="RO">RO</option>
                  <option value="RR">RR</option>
                  <option value="SC">SC</option>
                  <option value="SP">SP</option>
                  <option value="SE">SE</option>
                  <option value="TO">TO</option>
                </select>
              </div>
            </div>

            <div className="form-control">
              <label htmlFor="registerZipCode">CEP:</label>
              <input 
                type="text" 
                id="registerZipCode" 
                placeholder="00000-000" 
                maxLength={9}
                value={zipCode}
                onChange={maskZipCode}
              />
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button type="button" className="btn" style={{ flex: 1 }} onClick={prevStep}>VOLTAR</button>
              <button type="button" className="btn" style={{ flex: 1 }} onClick={nextStep}>PRÓXIMO</button>
            </div>
          </div>
        )}

        {/* Step 3 - Access */}
        {currentStep === 3 && (
          <div id="registerStep3">
            <h2 style={{ textAlign: 'center', color: '#6a0dad', marginBottom: '20px' }}>Dados de Acesso</h2>
            
            <div className="form-control">
              <label htmlFor="registerUsername">NOME DE USUÁRIO:</label>
              <input 
                type="text" 
                id="registerUsername" 
                placeholder="Escolha um nome de usuário"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>

            <div className="form-control">
              <label htmlFor="registerPassword">SENHA:</label>
              <input 
                type="password" 
                id="registerPassword" 
                placeholder="Digite sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <div style={{ marginTop: '-15px', marginBottom: '15px', fontSize: '12px', color: '#666' }}>
                A senha deve ter no mínimo 6 caracteres, incluindo letras e números
              </div>
            </div>

            <div className="form-control">
              <label htmlFor="confirmPassword">CONFIRMAR SENHA:</label>
              <input 
                type="password" 
                id="confirmPassword" 
                placeholder="Confirme sua senha"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>

            <div className="form-control">
              <label htmlFor="registerPreferredContact">CONTATO PREFERENCIAL:</label>
              <select 
                id="registerPreferredContact"
                value={preferredContact}
                onChange={(e) => setPreferredContact(e.target.value)}
              >
                <option value="" disabled>Selecione</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="telefone">Telefone</option>
                <option value="email">E-mail</option>
              </select>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', margin: '15px 0' }}>
              <input 
                type="checkbox" 
                id="termsCheckbox" 
                style={{ width: 'auto', margin: '0 10px 0 0' }}
                checked={termsAccepted}
                onChange={(e) => setTermsAccepted(e.target.checked)}
              />
              <label htmlFor="termsCheckbox" style={{ margin: 0 }}>
                Concordo com os <a href="#" style={{ color: '#6a0dad' }}>termos de uso</a> e <a href="#" style={{ color: '#6a0dad' }}>política de privacidade</a>
              </label>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button type="button" className="btn" style={{ flex: 1 }} onClick={prevStep}>VOLTAR</button>
              <button type="submit" className="btn" style={{ flex: 1 }}>CADASTRAR</button>
            </div>
          </div>
        )}
      </form>

      <div className="switch-button" style={{ marginTop: '20px' }}>
        <span>Já tem uma conta?</span>
        <button type="button" className="btn-link" onClick={onSwitchToLogin}>Entrar</button>
      </div>

      {message.text && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default RegisterForm;