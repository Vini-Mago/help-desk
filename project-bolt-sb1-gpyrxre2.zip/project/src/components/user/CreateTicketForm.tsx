import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { saveTicket } from '../../utils/fileSystem';
import { Ticket } from '../../utils/types';

const CreateTicketForm = () => {
  const { currentUser } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'technical' | 'financial' | 'inquiry' | ''>('');
  const [message, setMessage] = useState({ text: '', type: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title) {
      setMessage({ text: 'Por favor, informe um título para o ticket.', type: 'error' });
      return;
    }
    
    if (!description) {
      setMessage({ text: 'Por favor, descreva seu problema.', type: 'error' });
      return;
    }
    
    if (!type) {
      setMessage({ text: 'Por favor, selecione o tipo de problema.', type: 'error' });
      return;
    }
    
    const newTicket: Ticket = {
      id: '',
      userId: currentUser?.id || '',
      username: currentUser?.name || currentUser?.username || '',
      title,
      description,
      type: type as 'technical' | 'financial' | 'inquiry',
      status: 'pending',
      createdAt: '',
      updatedAt: ''
    };
    
    saveTicket(newTicket);
    
    setMessage({ text: 'Ticket criado com sucesso!', type: 'success' });
    setTitle('');
    setDescription('');
    setType('');
    
    setTimeout(() => {
      setMessage({ text: '', type: '' });
    }, 3000);
  };

  return (
    <div style={{ marginTop: '30px' }}>
      <h2 style={{ marginBottom: '20px', color: '#6a0dad' }}>Criar Novo Ticket</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-control">
          <label htmlFor="ticketTitle">TÍTULO:</label>
          <input 
            type="text" 
            id="ticketTitle" 
            placeholder="Título do seu ticket"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        
        <div className="form-control">
          <label htmlFor="ticketType">TIPO DE PROBLEMA:</label>
          <select 
            id="ticketType"
            value={type}
            onChange={(e) => setType(e.target.value as 'technical' | 'financial' | 'inquiry' | '')}
          >
            <option value="" disabled>Selecione o tipo</option>
            <option value="technical">Técnico</option>
            <option value="financial">Financeiro</option>
            <option value="inquiry">Dúvida</option>
          </select>
        </div>
        
        <div className="form-control">
          <label htmlFor="ticketDescription">DESCRIÇÃO:</label>
          <textarea 
            id="ticketDescription" 
            placeholder="Descreva seu problema em detalhes"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            style={{ 
              minHeight: '120px', 
              width: '100%',
              padding: '12px',
              backgroundColor: '#f1e4fc',
              border: '1px solid #bfa2db',
              borderRadius: '8px',
              fontSize: '16px',
              resize: 'vertical'
            }}
          />
        </div>
        
        <button type="submit" className="btn">ENVIAR TICKET</button>
      </form>
      
      {message.text && (
        <div className={`message ${message.type}`} style={{ marginTop: '20px' }}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default CreateTicketForm;