import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { getUserTickets } from '../../utils/fileSystem';
import { Ticket } from '../../utils/types';
import { Clock, CheckCircle2, HelpCircle } from 'lucide-react';

const UserTicketList = () => {
  const { currentUser } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  
  useEffect(() => {
    if (currentUser?.id) {
      const userTickets = getUserTickets(currentUser.id);
      setTickets(userTickets);
    }
  }, [currentUser]);
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="badge badge-pending">Pendente</span>;
      case 'inprogress':
        return <span className="badge badge-inprogress">Em andamento</span>;
      case 'resolved':
        return <span className="badge badge-resolved">Resolvido</span>;
      default:
        return null;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'technical':
        return <Clock size={18} />;
      case 'financial':
        return <CheckCircle2 size={18} />;
      case 'inquiry':
        return <HelpCircle size={18} />;
      default:
        return null;
    }
  };
  
  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'technical':
        return 'Técnico';
      case 'financial':
        return 'Financeiro';
      case 'inquiry':
        return 'Dúvida';
      default:
        return type;
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR');
  };
  
  return (
    <div style={{ marginTop: '30px' }}>
      <h2 style={{ marginBottom: '20px', color: '#6a0dad' }}>Meus Tickets</h2>
      
      {tickets.length === 0 ? (
        <div style={{ 
          backgroundColor: '#f1e4fc', 
          padding: '20px', 
          borderRadius: '8px', 
          textAlign: 'center',
          color: '#6a0dad'
        }}>
          Você ainda não possui tickets. Crie um novo ticket para receber ajuda.
        </div>
      ) : (
        <div>
          {tickets.map((ticket) => (
            <div key={ticket.id} className="ticket">
              <div className="ticket-header">
                <h3 className="ticket-title">{ticket.title}</h3>
                {getStatusBadge(ticket.status)}
              </div>
              
              <div className="ticket-body">
                <p>{ticket.description}</p>
              </div>
              
              <div className="ticket-footer">
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  {getTypeIcon(ticket.type)}
                  <span>{getTypeLabel(ticket.type)}</span>
                </div>
                <div>
                  Criado em: {formatDate(ticket.createdAt)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UserTicketList;