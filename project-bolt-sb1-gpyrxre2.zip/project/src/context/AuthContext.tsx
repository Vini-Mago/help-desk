import { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User, Admin } from '../utils/types';
import { getUsers, saveUser, getAdmins } from '../utils/fileSystem';

interface AuthContextType {
  currentUser: User | Admin | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => boolean;
  adminLogin: (username: string, password: string) => boolean;
  register: (user: User) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | Admin | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      setCurrentUser(user);
      setIsAuthenticated(true);
      setIsAdmin(user.role === 'admin');
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
      user.role = 'user';
      setCurrentUser(user);
      setIsAuthenticated(true);
      setIsAdmin(false);
      localStorage.setItem('currentUser', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const adminLogin = (username: string, password: string): boolean => {
    const admins = getAdmins();
    const admin = admins.find(a => a.username === username && a.password === password);
    
    if (admin) {
      setCurrentUser(admin);
      setIsAuthenticated(true);
      setIsAdmin(true);
      localStorage.setItem('currentUser', JSON.stringify(admin));
      return true;
    }
    return false;
  };

  const register = (user: User): boolean => {
    const users = getUsers();
    
    // Check if email already exists
    if (users.some(u => u.email === user.email)) {
      return false;
    }
    
    user.role = 'user';
    users.push(user);
    saveUser(user);
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    localStorage.removeItem('currentUser');
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      isAuthenticated,
      isAdmin,
      login,
      adminLogin,
      register,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};