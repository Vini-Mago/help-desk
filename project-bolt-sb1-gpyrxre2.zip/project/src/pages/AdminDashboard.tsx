import Header from '../components/common/Header';
import AdminTicketList from '../components/admin/AdminTicketList';

const AdminDashboard = () => {
  return (
    <div>
      <Header title="Painel de Administração" />
      
      <div className="container wide-container" style={{ maxWidth: '900px' }}>
        <AdminTicketList />
      </div>
    </div>
  );
};

export default AdminDashboard;