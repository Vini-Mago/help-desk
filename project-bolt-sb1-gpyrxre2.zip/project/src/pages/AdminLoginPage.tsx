import { Shield } from 'lucide-react';
import AdminLoginForm from '../components/auth/AdminLoginForm';

const AdminLoginPage = () => {
  const handleSwitchToUserLogin = () => {
    window.location.href = '/login';
  };

  return (
    <div className="centered">
      <div className="logo">
        <Shield size={80} color="#6a0dad" />
      </div>
      <div className="container">
        <AdminLoginForm onSwitchToUserLogin={handleSwitchToUserLogin} />
      </div>
    </div>
  );
};

export default AdminLoginPage;