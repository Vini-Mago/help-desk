import { useState } from 'react';
import LoginForm from '../components/auth/LoginForm';
import { LogIn } from 'lucide-react';

const LoginPage = () => {
  const handleSwitchToRegister = () => {
    window.location.href = '/register';
  };

  const handleSwitchToAdminLogin = () => {
    window.location.href = '/admin-login';
  };

  return (
    <div className="centered">
      <div className="logo">
        <LogIn size={80} color="#6a0dad" />
      </div>
      <div className="container">
        <LoginForm 
          onSwitchToRegister={handleSwitchToRegister}
          onSwitchToAdminLogin={handleSwitchToAdminLogin}
        />
      </div>
    </div>
  );
};

export default LoginPage;