import { UserPlus } from 'lucide-react';
import RegisterForm from '../components/auth/RegisterForm';

const RegisterPage = () => {
  const handleSwitchToLogin = () => {
    window.location.href = '/login';
  };

  return (
    <div className="centered">
      <div className="logo">
        <UserPlus size={80} color="#6a0dad" />
      </div>
      <div className="container">
        <RegisterForm onSwitchToLogin={handleSwitchToLogin} />
      </div>
    </div>
  );
};

export default RegisterPage;