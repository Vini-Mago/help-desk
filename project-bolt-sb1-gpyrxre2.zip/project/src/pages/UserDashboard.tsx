import { useState } from 'react';
import Header from '../components/common/Header';
import CreateTicketForm from '../components/user/CreateTicketForm';
import UserTicketList from '../components/user/UserTicketList';
import { TicketPlus, ClipboardList } from 'lucide-react';

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState<'create' | 'list'>('list');
  
  return (
    <div>
      <Header title="Painel do Usuário" />
      
      <div className="container wide-container" style={{ maxWidth: '800px' }}>
        <div style={{ 
          display: 'flex', 
          borderBottom: '1px solid #ddd', 
          marginBottom: '20px',
          gap: '10px'
        }}>
          <button 
            onClick={() => setActiveTab('list')}
            className={`btn-link ${activeTab === 'list' ? 'active' : ''}`}
            style={{ 
              padding: '10px 16px', 
              borderBottom: activeTab === 'list' ? '3px solid #6a0dad' : '3px solid transparent',
              color: activeTab === 'list' ? '#6a0dad' : '#666',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              textDecoration: 'none',
              fontWeight: activeTab === 'list' ? 'bold' : 'normal'
            }}
          >
            <ClipboardList size={18} /> Meus Tickets
          </button>
          <button 
            onClick={() => setActiveTab('create')}
            className={`btn-link ${activeTab === 'create' ? 'active' : ''}`}
            style={{ 
              padding: '10px 16px', 
              borderBottom: activeTab === 'create' ? '3px solid #6a0dad' : '3px solid transparent',
              color: activeTab === 'create' ? '#6a0dad' : '#666',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              textDecoration: 'none',
              fontWeight: activeTab === 'create' ? 'bold' : 'normal'
            }}
          >
            <TicketPlus size={18} /> Criar Ticket
          </button>
        </div>
        
        {activeTab === 'create' ? <CreateTicketForm /> : <UserTicketList />}
      </div>
    </div>
  );
};

export default UserDashboard;