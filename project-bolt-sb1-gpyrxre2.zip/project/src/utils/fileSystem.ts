import { User, Admin, Ticket } from './types';

// Simulated file system using localStorage
// In a real app, this would interact with actual text files via Node.js

// Initial admin user (pre-defined)
const defaultAdmin: Admin = {
  id: 'admin-1',
  username: 'admin',
  password: 'admin123',
  name: 'System Administrator',
  role: 'admin'
};

// Initialize storage if empty
const initializeStorage = () => {
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('tickets')) {
    localStorage.setItem('tickets', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('admins')) {
    localStorage.setItem('admins', JSON.stringify([defaultAdmin]));
  }
};

// Initialize on import
initializeStorage();

// User operations
export const getUsers = (): User[] => {
  const users = localStorage.getItem('users');
  return users ? JSON.parse(users) : [];
};

export const saveUser = (user: User): void => {
  const users = getUsers();
  
  // Generate ID if not present
  if (!user.id) {
    user.id = 'user-' + Date.now();
  }
  
  // Check if user exists (update) or is new (add)
  const existingIndex = users.findIndex(u => u.id === user.id);
  
  if (existingIndex >= 0) {
    users[existingIndex] = user;
  } else {
    users.push(user);
  }
  
  localStorage.setItem('users', JSON.stringify(users));
  
  // For text file simulation
  exportUsersToText();
};

// Admin operations
export const getAdmins = (): Admin[] => {
  const admins = localStorage.getItem('admins');
  return admins ? JSON.parse(admins) : [defaultAdmin];
};

// Ticket operations
export const getTickets = (): Ticket[] => {
  const tickets = localStorage.getItem('tickets');
  return tickets ? JSON.parse(tickets) : [];
};

export const getUserTickets = (userId: string): Ticket[] => {
  const tickets = getTickets();
  return tickets.filter(ticket => ticket.userId === userId);
};

export const saveTicket = (ticket: Ticket): void => {
  const tickets = getTickets();
  
  // Generate ID if not present
  if (!ticket.id) {
    ticket.id = 'ticket-' + Date.now();
    ticket.createdAt = new Date().toISOString();
  }
  
  ticket.updatedAt = new Date().toISOString();
  
  // Check if ticket exists (update) or is new (add)
  const existingIndex = tickets.findIndex(t => t.id === ticket.id);
  
  if (existingIndex >= 0) {
    tickets[existingIndex] = ticket;
  } else {
    tickets.push(ticket);
  }
  
  localStorage.setItem('tickets', JSON.stringify(tickets));
  
  // For text file simulation
  exportTicketsToText();
};

export const updateTicketStatus = (ticketId: string, status: 'pending' | 'inprogress' | 'resolved'): boolean => {
  const tickets = getTickets();
  const ticketIndex = tickets.findIndex(t => t.id === ticketId);
  
  if (ticketIndex >= 0) {
    tickets[ticketIndex].status = status;
    tickets[ticketIndex].updatedAt = new Date().toISOString();
    localStorage.setItem('tickets', JSON.stringify(tickets));
    exportTicketsToText();
    return true;
  }
  
  return false;
};

// Export functions for text file simulation
export const exportUsersToText = (): string => {
  const users = getUsers();
  let textContent = 'USER DATA\n==========\n\n';
  
  users.forEach(user => {
    textContent += `ID: ${user.id}\n`;
    textContent += `Name: ${user.name}\n`;
    textContent += `Email: ${user.email}\n`;
    textContent += `Password: ${'*'.repeat(user.password.length)}\n`;
    textContent += `Phone: ${user.phone}\n`;
    textContent += `Birth Date: ${user.birthdate}\n`;
    textContent += `Gender: ${user.gender}\n`;
    textContent += `Location: ${user.city}, ${user.state} - ${user.zipCode}\n`;
    textContent += `Username: ${user.username}\n`;
    textContent += `Preferred Contact: ${user.preferredContact}\n`;
    textContent += '----------------------\n\n';
  });
  
  // In a real app, this would write to an actual file
  return textContent;
};

export const exportTicketsToText = (): string => {
  const tickets = getTickets();
  let textContent = 'TICKET DATA\n===========\n\n';
  
  tickets.forEach(ticket => {
    textContent += `Ticket ID: ${ticket.id}\n`;
    textContent += `User: ${ticket.username} (${ticket.userId})\n`;
    textContent += `Title: ${ticket.title}\n`;
    textContent += `Type: ${ticket.type}\n`;
    textContent += `Status: ${ticket.status}\n`;
    textContent += `Created: ${new Date(ticket.createdAt).toLocaleString()}\n`;
    textContent += `Updated: ${new Date(ticket.updatedAt).toLocaleString()}\n`;
    textContent += `Description: ${ticket.description}\n`;
    textContent += '----------------------\n\n';
  });
  
  // In a real app, this would write to an actual file
  return textContent;
};

// Function to download as a text file
export const downloadAsTextFile = (content: string, filename: string): void => {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};