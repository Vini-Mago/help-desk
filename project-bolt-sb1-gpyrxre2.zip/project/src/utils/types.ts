export interface User {
  id?: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  birthdate: string;
  gender: string;
  city: string;
  state: string;
  zipCode: string;
  username: string;
  preferredContact: string;
  role?: string;
}

export interface Admin {
  id: string;
  username: string;
  password: string;
  name: string;
  role: string;
}

export interface Ticket {
  id: string;
  userId: string;
  username: string;
  title: string;
  description: string;
  type: 'technical' | 'financial' | 'inquiry';
  status: 'pending' | 'inprogress' | 'resolved';
  createdAt: string;
  updatedAt: string;
}